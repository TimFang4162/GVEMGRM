#' A simulated dataset for multidemensional graded response model.
#'
#' @format The dataset contains the simulation setting and the response data.
#' \tabular{ll}{
#'   \code{true_A} \tab true slope parameters with dimension 12*2.\cr
#'   \code{true_B} \tab true threshold parameters with dimension 12*4.\cr
#'   \code{true_Sig} \tab true correlation of latent traits with dimension 2*2.\cr
#'   \code{theta} \tab individual scores with dimension 200*2.\cr
#'   \code{y} \tab graded response with dimension 200*12.\cr
#' }
#' @usage toy_data
"toy_data"
